from .instabot import InstaBot

VERSION = '0.5.2'
__all__ = ['InstaBot']
__version__ = VERSION
